<div class="pull-right">
		<footer>
           <p>Programmed by: TechThinkers</p>
        <footer>
</div>