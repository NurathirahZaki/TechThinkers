<?php
$conn = mysqli_connect('localhost','root','','tryintellilearn') or die(mysqli_error());
?>